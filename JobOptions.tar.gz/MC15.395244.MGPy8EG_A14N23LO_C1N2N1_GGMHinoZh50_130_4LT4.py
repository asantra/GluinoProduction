include('MC15JobOptions/MadGraphControl_SimplifiedModel_C1N2N1_GGMHino_Filter.py') 
evgenConfig.minevents = 2000 
